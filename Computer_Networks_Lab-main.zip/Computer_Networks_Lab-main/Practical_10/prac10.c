#include <stdio.h>

#define MAX 10
#define INF 9999

int main()
{
    int n;
    int cost[MAX][MAX];
    int dist[MAX][MAX];
    int nextHop[MAX][MAX];

    int i, j, k;
    int updated;

    printf("Enter the number of routers: ");
    scanf("%d", &n);

    printf("\nEnter the cost matrix:\n");
    printf("Enter 9999 for no direct connection\n\n");

    for (i = 0; i < n; i++)
    {
        for (j = 0; j < n; j++)
        {
            scanf("%d", &cost[i][j]);

            dist[i][j] = cost[i][j];

            if (i == j)
                nextHop[i][j] = i;
            else if (cost[i][j] != INF)
                nextHop[i][j] = j;
            else
                nextHop[i][j] = -1;
        }
    }

    do
    {
        updated = 0;

        for (i = 0; i < n; i++)
        {
            for (j = 0; j < n; j++)
            {
                for (k = 0; k < n; k++)
                {
                    if (dist[i][k] != INF && cost[k][j] != INF)
                    {
                        if (dist[i][j] > dist[i][k] + cost[k][j])
                        {
                            dist[i][j] = dist[i][k] + cost[k][j];

                            if (i != k)
                                nextHop[i][j] = nextHop[i][k];

                            updated = 1;
                        }
                    }
                }
            }
        }

    } while (updated);

    printf("\n\n=========== DISTANCE VECTOR ROUTING TABLES ===========\n");

    for (i = 0; i < n; i++)
    {
        printf("\nRouter %d:\n", i + 1);
        printf("--------------------\n");
        printf("Destination\tCost\tNextHop\n");
        printf("--------------------\n");

        for (j = 0; j < n; j++)
        {
            printf("%d\t\t", j + 1);

            if (dist[i][j] == INF)
                printf("INF\t");
            else
                printf("%d\t", dist[i][j]);

            if (nextHop[i][j] == -1)
                printf("-\n");
            else
                printf("%d\n", nextHop[i][j] + 1);
        }
    }

    return 0;
}
